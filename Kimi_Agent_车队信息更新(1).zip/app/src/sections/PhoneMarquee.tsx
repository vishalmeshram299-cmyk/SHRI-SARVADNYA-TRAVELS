import { Phone } from 'lucide-react';

const marqueeContent = (
  <>
    <span className="flex items-center gap-4 mx-8 whitespace-nowrap">
      <Phone size={32} className="opacity-40" />
      <span>9049168062</span>
      <span className="text-[#D4A843] text-2xl mx-4">&#9670;</span>
    </span>
    <span className="flex items-center gap-4 mx-8 whitespace-nowrap">
      <Phone size={32} className="opacity-40" />
      <span>8390823639</span>
      <span className="text-[#D4A843] text-2xl mx-4">&#9670;</span>
    </span>
    <span className="flex items-center gap-4 mx-8 whitespace-nowrap">
      <Phone size={32} className="opacity-40" />
      <span>9028520865</span>
      <span className="text-[#D4A843] text-2xl mx-4">&#9670;</span>
    </span>
    <span className="flex items-center gap-4 mx-8 whitespace-nowrap">
      <span>WHATSAPP BOOKING</span>
      <span className="text-[#D4A843] text-2xl mx-4">&#9670;</span>
    </span>
    <span className="flex items-center gap-4 mx-8 whitespace-nowrap">
      <span>24/7 SERVICE</span>
      <span className="text-[#D4A843] text-2xl mx-4">&#9670;</span>
    </span>
    <span className="flex items-center gap-4 mx-8 whitespace-nowrap">
      <span>SHRI SARVADNYA TRAVELS</span>
      <span className="text-[#D4A843] text-2xl mx-4">&#9670;</span>
    </span>
  </>
);

export default function PhoneMarquee() {
  return (
    <section className="w-full h-[80px] bg-[#1A1A1A] border-y border-[rgba(245,245,240,0.15)] overflow-hidden flex items-center">
      <div className="animate-marquee flex items-center whitespace-nowrap">
        <span className="font-display font-black text-[#D4A843]/15" style={{ fontSize: 'clamp(2rem, 4vw, 3.5rem)' }}>
          {marqueeContent}
          {marqueeContent}
          {marqueeContent}
          {marqueeContent}
        </span>
      </div>
    </section>
  );
}
