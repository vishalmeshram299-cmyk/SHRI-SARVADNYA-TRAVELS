import { useScrollReveal } from '../hooks/useScrollReveal';
import { Wind, Music, Tv, Users, Star, MapPin } from 'lucide-react';

interface Feature {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const features: Feature[] = [
  {
    icon: (
      <svg width="48" height="48" viewBox="0 0 48 48" fill="none" className="text-[#D4A843]">
        <circle cx="24" cy="24" r="18" stroke="currentColor" strokeWidth="2" strokeDasharray="4 4" />
        <circle cx="24" cy="24" r="12" stroke="currentColor" strokeWidth="2" />
        <circle cx="24" cy="24" r="6" fill="currentColor" opacity="0.3" />
        <circle cx="24" cy="24" r="3" fill="currentColor" />
      </svg>
    ),
    title: 'Green LED Ceiling Lights',
    description: 'Beautiful multi-color LED rings on ceiling with disco/party lighting mode for a festive atmosphere',
  },
  {
    icon: <Wind size={48} className="text-[#D4A843]" />,
    title: 'Fully Air Conditioned',
    description: 'Powerful AC with roof-mounted units ensuring comfortable temperature even in peak summer',
  },
  {
    icon: <Music size={48} className="text-[#D4A843]" />,
    title: 'Music System',
    description: 'High-quality sound system with speakers throughout the vehicle for an enjoyable journey',
  },
  {
    icon: <Tv size={48} className="text-[#D4A843]" />,
    title: 'LED TV Screen',
    description: 'Large screen LED TV for entertainment — perfect for long journeys with movies and music videos',
  },
  {
    icon: <Users size={48} className="text-[#D4A843]" />,
    title: 'Luxury Velvet Seats',
    description: 'Premium cream/beige velvet seat covers with comfortable cushioning for fatigue-free travel',
  },
  {
    icon: <Star size={48} className="text-[#D4A843]" />,
    title: 'Recliner Seats (New Bus)',
    description: 'Brand new white recliner seats with individual pockets and premium comfort in our luxury mini bus',
  },
  {
    icon: (
      <svg width="48" height="48" viewBox="0 0 48 48" fill="none" className="text-[#D4A843]">
        <path d="M8 8 L8 40 L16 40 L16 28 L32 28 L32 40 L40 40 L40 8 L8 8Z" stroke="currentColor" strokeWidth="2" fill="none" />
        <line x1="8" y1="16" x2="40" y2="16" stroke="currentColor" strokeWidth="1.5" opacity="0.5" />
        <line x1="8" y1="24" x2="40" y2="24" stroke="currentColor" strokeWidth="1.5" opacity="0.3" />
      </svg>
    ),
    title: 'Privacy Curtains',
    description: 'Dark curtains on all windows for privacy and shade, creating a personal space for your group',
  },
  {
    icon: <MapPin size={48} className="text-[#D4A843]" />,
    title: 'Roof Luggage Carrier',
    description: 'Spacious roof carrier for extra luggage — no need to compromise on baggage for group travel',
  },
];

function FeatureCard({ feature, index }: { feature: Feature; index: number }) {
  const cardRef = useScrollReveal<HTMLDivElement>({ delay: index * 100 });

  return (
    <div
      ref={cardRef}
      className="bg-[#1A1A1A] rounded-xl p-8 transition-all duration-200 hover:-translate-y-2 hover:shadow-[0_12px_40px_rgba(0,0,0,0.4)]"
    >
      <div className="mb-4">{feature.icon}</div>
      <h3 className="font-display text-lg font-semibold text-[#F5F5F0] mb-2">
        {feature.title}
      </h3>
      <p className="font-body text-sm text-[#A3A39B] leading-relaxed">
        {feature.description}
      </p>
    </div>
  );
}

export default function InteriorFeatures() {
  const headerRef = useScrollReveal<HTMLDivElement>();

  return (
    <section
      id="features"
      className="w-full py-20 lg:py-28 px-6 lg:px-12 border-t border-[rgba(245,245,240,0.15)]"
      style={{ backgroundColor: '#0A0A0A' }}
    >
      <div className="max-w-[1280px] mx-auto">
        {/* Section Header */}
        <div ref={headerRef} className="mb-12 text-center">
          <span className="inline-block font-body text-xs font-medium uppercase tracking-[0.08em] bg-[rgba(212,168,67,0.15)] text-[#D4A843] px-4 py-2 rounded mb-4">
            INTERIOR FEATURES
          </span>
          <h2 className="font-display font-bold text-[#F5F5F0] mb-4" style={{ fontSize: 'clamp(1.8rem, 3vw, 3rem)' }}>
            Travel in Comfort & Style
          </h2>
          <p className="font-body text-lg text-[#A3A39B] max-w-2xl mx-auto">
            Every vehicle is equipped with premium amenities to make your journey memorable
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <FeatureCard key={feature.title} feature={feature} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
