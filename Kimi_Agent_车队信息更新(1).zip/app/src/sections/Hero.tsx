import { useEffect, useRef } from 'react';
import { Phone, ChevronDown } from 'lucide-react';

export default function Hero() {
  const badgeRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const descRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const phoneRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const elements = [
      { el: badgeRef.current, delay: 200 },
      { el: titleRef.current, delay: 400 },
      { el: subtitleRef.current, delay: 600 },
      { el: descRef.current, delay: 800 },
      { el: ctaRef.current, delay: 1000 },
      { el: phoneRef.current, delay: 1200 },
    ];

    elements.forEach(({ el, delay }) => {
      if (el) {
        el.style.opacity = '0';
        el.style.transform = 'translateY(40px)';
        el.style.transition = `opacity 800ms cubic-bezier(0.16, 1, 0.3, 1) ${delay}ms, transform 800ms cubic-bezier(0.16, 1, 0.3, 1) ${delay}ms`;
        
        requestAnimationFrame(() => {
          requestAnimationFrame(() => {
            el.style.opacity = '1';
            el.style.transform = 'translateY(0)';
          });
        });
      }
    });
  }, []);

  return (
    <section
      id="home"
      className="relative min-h-[100dvh] flex items-center justify-center overflow-hidden"
      style={{ backgroundColor: '#0A0A0A' }}
    >
      {/* Decorative Background Elements - Vehicle Silhouettes */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Large silhouette left */}
        <div 
          className="absolute -left-20 top-1/2 -translate-y-1/2 w-[500px] h-[300px] opacity-[0.04]"
          style={{
            background: 'linear-gradient(135deg, #fff 0%, transparent 60%)',
            borderRadius: '20px 60px 20px 40px',
          }}
        />
        {/* Large silhouette right */}
        <div 
          className="absolute -right-10 top-1/3 w-[400px] h-[250px] opacity-[0.03]"
          style={{
            background: 'linear-gradient(-135deg, #fff 0%, transparent 60%)',
            borderRadius: '40px 20px 60px 20px',
          }}
        />
        {/* Small accent shapes */}
        <div className="absolute top-20 left-1/4 w-2 h-2 bg-[#D4A843] opacity-20 rotate-45" />
        <div className="absolute bottom-32 right-1/3 w-3 h-3 bg-[#D4A843] opacity-10 rotate-45" />
        <div className="absolute top-1/3 right-20 w-1.5 h-1.5 bg-[#D4A843] opacity-15 rotate-45" />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-6 max-w-4xl mx-auto">
        {/* Badge */}
        <div ref={badgeRef} className="mb-6">
          <span className="inline-block font-body text-xs font-medium uppercase tracking-[0.08em] bg-[rgba(212,168,67,0.15)] text-[#D4A843] px-4 py-2 rounded">
            PREMIUM TEMPO TRAVELLER & BUS RENTAL
          </span>
        </div>

        {/* Main Title */}
        <h1
          ref={titleRef}
          className="font-display font-extrabold text-[#F5F5F0] leading-[1.05] tracking-tight mb-4"
          style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}
        >
          SHRI SARVADNYA TRAVELS
        </h1>

        {/* Hindi Subtitle */}
        <p
          ref={subtitleRef}
          className="font-display font-semibold text-[#D4A843] mb-6"
          style={{ fontSize: 'clamp(1.2rem, 2.5vw, 1.8rem)' }}
        >
          आपकी यात्रा, हमारी जिम्मेदारी
        </p>

        {/* Description */}
        <p
          ref={descRef}
          className="font-body text-lg text-[#A3A39B] max-w-2xl mx-auto mb-8 leading-relaxed"
        >
          Luxury Tempo Traveller & Mini Bus on rent for all your travel needs. 
          17-seater to 32-seater vehicles available with AC, LED lights, music system & comfortable seating. 
          24-hour service available across Maharashtra.
        </p>

        {/* CTA Buttons */}
        <div ref={ctaRef} className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-6">
          <a
            href="https://wa.me/919049168062"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-[#D4A843] text-[#0A0A0A] font-body text-base font-semibold px-8 py-4 rounded-md hover:bg-[#E8C76A] hover:scale-[1.02] transition-all duration-200 w-full sm:w-auto justify-center"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
            </svg>
            Book on WhatsApp
          </a>
          <a
            href="tel:9049168062"
            className="inline-flex items-center gap-2 border border-[#D4A843] text-[#D4A843] font-body text-base font-semibold px-8 py-4 rounded-md hover:bg-[#D4A843] hover:text-[#0A0A0A] transition-all duration-200 w-full sm:w-auto justify-center"
          >
            <Phone size={18} />
            Call Now
          </a>
        </div>

        {/* Phone Numbers */}
        <div ref={phoneRef} className="flex flex-wrap items-center justify-center gap-4 sm:gap-6 text-sm text-[#A3A39B]">
          <a href="tel:9049168062" className="flex items-center gap-1.5 hover:text-[#D4A843] transition-colors">
            <Phone size={14} />
            <span>9049168062</span>
          </a>
          <span className="text-[#D4A843] opacity-50 hidden sm:inline">|</span>
          <a href="tel:8390823639" className="flex items-center gap-1.5 hover:text-[#D4A843] transition-colors">
            <Phone size={14} />
            <span>8390823639</span>
          </a>
          <span className="text-[#D4A843] opacity-50 hidden sm:inline">|</span>
          <a href="tel:9028520865" className="flex items-center gap-1.5 hover:text-[#D4A843] transition-colors">
            <Phone size={14} />
            <span>9028520865</span>
          </a>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 text-[#A3A39B]/50 animate-bounce-gentle">
        <ChevronDown size={28} />
      </div>
    </section>
  );
}
