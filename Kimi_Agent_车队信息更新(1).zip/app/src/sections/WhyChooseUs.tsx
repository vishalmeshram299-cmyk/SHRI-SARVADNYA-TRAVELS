import { useScrollReveal } from '../hooks/useScrollReveal';
import { Clock, Shield, Star, MapPin, Users, CheckCircle } from 'lucide-react';

interface WhyUsItem {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const items: WhyUsItem[] = [
  {
    icon: <Clock size={40} className="text-[#D4A843]" />,
    title: '24/7 Service Available',
    description: "Round-the-clock service available. Book anytime — we're always ready for your journey.",
  },
  {
    icon: <Shield size={40} className="text-[#D4A843]" />,
    title: 'Experienced Drivers',
    description: 'Professional, licensed, and courteous drivers with years of experience on Maharashtra roads.',
  },
  {
    icon: <Star size={40} className="text-[#D4A843]" />,
    title: 'Well-Maintained Fleet',
    description: 'All vehicles regularly serviced and inspected. Clean, hygienic interiors for every trip.',
  },
  {
    icon: (
      <svg width="40" height="40" viewBox="0 0 24 24" fill="none" className="text-[#D4A843]">
        <path d="M12 2v20M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
    title: 'Affordable Pricing',
    description: 'Competitive rates with no hidden charges. Get the best value for premium comfort.',
  },
  {
    icon: <MapPin size={40} className="text-[#D4A843]" />,
    title: 'All India Permit',
    description: 'Our vehicles have all-India permits. Travel anywhere in India without any restrictions.',
  },
  {
    icon: <Users size={40} className="text-[#D4A843]" />,
    title: 'Multiple Vehicle Options',
    description: 'From 14-seater to 32-seater — choose the right vehicle size for your group and budget.',
  },
  {
    icon: (
      <svg width="40" height="40" viewBox="0 0 24 24" fill="currentColor" className="text-[#D4A843]">
        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
      </svg>
    ),
    title: 'Easy WhatsApp Booking',
    description: 'Book instantly via WhatsApp. Share your travel plan and get a quick confirmation.',
  },
  {
    icon: <CheckCircle size={40} className="text-[#D4A843]" />,
    title: 'Punctual Service',
    description: 'We value your time. Our vehicles arrive on time, every time — guaranteed.',
  },
];

function WhyUsCard({ item, index }: { item: WhyUsItem; index: number }) {
  const cardRef = useScrollReveal<HTMLDivElement>({ delay: index * 100 });

  return (
    <div
      ref={cardRef}
      className="bg-white/60 backdrop-blur-sm border border-[rgba(10,10,10,0.12)] rounded-xl p-8 text-center transition-all duration-200 hover:-translate-y-2 hover:shadow-lg"
    >
      <div className="flex justify-center mb-4">{item.icon}</div>
      <h3 className="font-display text-lg font-semibold text-[#0A0A0A] mb-2">
        {item.title}
      </h3>
      <p className="font-body text-sm text-[#666660] leading-relaxed">
        {item.description}
      </p>
    </div>
  );
}

export default function WhyChooseUs() {
  const headerRef = useScrollReveal<HTMLDivElement>();

  return (
    <section
      id="whyus"
      className="w-full py-20 lg:py-28 px-6 lg:px-12"
      style={{ backgroundColor: '#FFFFFF' }}
    >
      <div className="max-w-[1280px] mx-auto">
        {/* Section Header */}
        <div ref={headerRef} className="mb-12 text-center">
          <span className="inline-block font-body text-xs font-medium uppercase tracking-[0.08em] bg-[rgba(212,168,67,0.1)] text-[#D4A843] px-4 py-2 rounded mb-4">
            WHY CHOOSE US
          </span>
          <h2 className="font-display font-bold text-[#0A0A0A] mb-4" style={{ fontSize: 'clamp(1.8rem, 3vw, 3rem)' }}>
            Why Choose Shri Sarvadnya Travels?
          </h2>
          <p className="font-body text-lg text-[#666660] max-w-2xl mx-auto">
            We go the extra mile to ensure your journey is safe, comfortable, and memorable
          </p>
        </div>

        {/* Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {items.map((item, index) => (
            <WhyUsCard key={item.title} item={item} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
