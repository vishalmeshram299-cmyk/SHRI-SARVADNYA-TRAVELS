import { useScrollReveal } from '../hooks/useScrollReveal';
import { useState } from 'react';

interface Vehicle {
  id: number;
  name: string;
  subtitle: string;
  regNumber: string;
  seats: string;
  image: string;
  hoverImage: string;
  features: string[];
  whatsappNumber: string;
}

const vehicles: Vehicle[] = [
  {
    id: 1,
    name: 'Night Queen',
    subtitle: 'Force Traveller',
    regNumber: 'MH 40 CT 1320',
    seats: '20 SEATER',
    image: '/vehicles/1000047261.jpg',
    hoverImage: '/vehicles/1000047221.jpg',
    features: ['AC', 'LED Disco Lights', 'Music System', 'Velvet Seats', 'Curtains', 'Roof Carrier'],
    whatsappNumber: '919049168062',
  },
  {
    id: 2,
    name: 'Shri Sarvadnya',
    subtitle: 'Force Traveller',
    regNumber: 'MH 09 CV 0972',
    seats: '17 SEATER',
    image: '/vehicles/1000047243.jpg',
    hoverImage: '/vehicles/1000047253.jpg',
    features: ['AC', 'LED Lights', 'Music System', 'Comfortable Seats', 'Curtains'],
    whatsappNumber: '919049168062',
  },
  {
    id: 3,
    name: 'Luxury Mini Bus',
    subtitle: 'Brand New Recliner',
    regNumber: 'Brand New Vehicle',
    seats: '32 SEATER',
    image: '/vehicles/1000047260.jpg',
    hoverImage: '/vehicles/1000047229.jpg',
    features: ['AC', 'Recliner Seats', 'LED TV', 'Ambient Lighting', 'Seat Pockets', 'Premium Interior'],
    whatsappNumber: '919049168062',
  },
];

function VehicleCard({ vehicle, index }: { vehicle: Vehicle; index: number }) {
  const cardRef = useScrollReveal<HTMLDivElement>({ delay: index * 100 });
  const [isHovered, setIsHovered] = useState(false);

  const message = encodeURIComponent(`Hi, I want to book the ${vehicle.name} (${vehicle.seats}) for my trip. Please share details.`);
  const whatsappLink = `https://wa.me/${vehicle.whatsappNumber}?text=${message}`;

  return (
    <div
      ref={cardRef}
      className="bg-[#1A1A1A] rounded-xl overflow-hidden transition-all duration-400 hover:scale-[1.03] hover:shadow-[0_20px_60px_rgba(0,0,0,0.3)] group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Image Container */}
      <div className="relative aspect-[16/10] overflow-hidden bg-[#111]">
        <img
          src={isHovered ? vehicle.hoverImage : vehicle.image}
          alt={`${vehicle.name} - ${vehicle.subtitle}`}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        {/* Seat Badge */}
        <div className="absolute top-4 left-4">
          <span className="font-body text-xs font-semibold uppercase tracking-wider bg-[#D4A843] text-[#0A0A0A] px-3 py-1.5 rounded">
            {vehicle.seats}
          </span>
        </div>
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#1A1A1A] via-transparent to-transparent opacity-60" />
      </div>

      {/* Content */}
      <div className="p-6">
        <h3 className="font-display text-xl font-semibold text-[#F5F5F0] mb-1">
          {vehicle.name}
        </h3>
        <p className="font-body text-sm text-[#D4A843] mb-3">
          {vehicle.subtitle}
        </p>
        <p className="font-body text-xs text-[#A3A39B] mb-4">
          Reg: {vehicle.regNumber}
        </p>

        {/* Features */}
        <div className="flex flex-wrap gap-2 mb-5">
          {vehicle.features.map((feature) => (
            <span
              key={feature}
              className="font-body text-xs text-[#A3A39B] bg-[#0A0A0A] border border-[rgba(245,245,240,0.15)] px-2.5 py-1 rounded"
            >
              {feature}
            </span>
          ))}
        </div>

        {/* CTA Button */}
        <a
          href={whatsappLink}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center justify-center w-full bg-[#D4A843] text-[#0A0A0A] font-body text-sm font-semibold py-3 rounded-md hover:bg-[#E8C76A] transition-colors duration-200"
        >
          Book This Vehicle
        </a>
      </div>
    </div>
  );
}

export default function Fleet() {
  const headerRef = useScrollReveal<HTMLDivElement>();

  return (
    <section
      id="fleet"
      className="w-full py-20 lg:py-28 px-6 lg:px-12"
      style={{ backgroundColor: '#0A0A0A' }}
    >
      <div className="max-w-[1280px] mx-auto">
        {/* Section Header */}
        <div ref={headerRef} className="mb-12 text-center">
          <span className="inline-block font-body text-xs font-medium uppercase tracking-[0.08em] bg-[rgba(212,168,67,0.15)] text-[#D4A843] px-4 py-2 rounded mb-4">
            OUR FLEET
          </span>
          <h2 className="font-display font-bold text-[#F5F5F0] mb-4" style={{ fontSize: 'clamp(1.8rem, 3vw, 3rem)' }}>
            Premium Vehicles for Every Journey
          </h2>
          <p className="font-body text-lg text-[#A3A39B] max-w-2xl mx-auto">
            17-seater Tempo Traveller to 32-seater Luxury Bus — choose the perfect vehicle for your group
          </p>
        </div>

        {/* Vehicle Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {vehicles.map((vehicle, index) => (
            <VehicleCard key={vehicle.id} vehicle={vehicle} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
