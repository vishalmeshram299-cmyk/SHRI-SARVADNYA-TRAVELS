import { useState, useEffect } from 'react';
import { Menu, X, Phone } from 'lucide-react';

const navLinks = [
  { label: 'HOME', href: '#home' },
  { label: 'FLEET', href: '#fleet' },
  { label: 'FEATURES', href: '#features' },
  { label: 'WHY US', href: '#whyus' },
  { label: 'CONTACT', href: '#contact' },
];

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setIsOpen(false);
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled ? 'bg-[#1A1A1A]/95 backdrop-blur-xl shadow-lg' : 'bg-[#1A1A1A]/85 backdrop-blur-md'
        }`}
        style={{ height: '72px' }}
      >
        <div className="max-w-[1280px] mx-auto h-full flex items-center justify-between px-6 lg:px-12">
          {/* Business Name */}
          <a
            href="#home"
            onClick={(e) => handleNavClick(e, '#home')}
            className="font-display text-[#D4A843] font-bold text-lg lg:text-xl tracking-tight hover:opacity-90 transition-opacity"
          >
            SHRI SARVADNYA TRAVELS
          </a>

          {/* Desktop Nav Links */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="font-body text-sm font-medium text-[#F5F5F0] hover:text-[#D4A843] transition-colors duration-200 tracking-widest uppercase"
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* Desktop CTA */}
          <a
            href="https://wa.me/919049168062"
            target="_blank"
            rel="noopener noreferrer"
            className="hidden md:inline-flex items-center gap-2 bg-[#D4A843] text-[#0A0A0A] font-body text-sm font-semibold px-5 py-2.5 rounded-md hover:bg-[#E8C76A] hover:scale-[1.02] transition-all duration-200"
          >
            <Phone size={16} />
            Book on WhatsApp
          </a>

          {/* Mobile Hamburger */}
          <button
            onClick={() => setIsOpen(true)}
            className="md:hidden text-[#F5F5F0] hover:text-[#D4A843] transition-colors p-2"
            aria-label="Open menu"
          >
            <Menu size={24} />
          </button>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <div
        className={`fixed inset-0 z-[60] bg-[#0A0A0A] transition-transform duration-400 md:hidden ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
        style={{ transitionDuration: '400ms' }}
      >
        <div className="flex flex-col h-full p-8">
          {/* Close Button */}
          <div className="flex justify-end">
            <button
              onClick={() => setIsOpen(false)}
              className="text-[#F5F5F0] hover:text-[#D4A843] transition-colors p-2"
              aria-label="Close menu"
            >
              <X size={28} />
            </button>
          </div>

          {/* Nav Links */}
          <div className="flex flex-col items-center justify-center flex-1 gap-8">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="font-display text-2xl font-semibold text-[#F5F5F0] hover:text-[#D4A843] transition-colors duration-200"
              >
                {link.label}
              </a>
            ))}

            <a
              href="https://wa.me/919049168062"
              target="_blank"
              rel="noopener noreferrer"
              className="mt-4 inline-flex items-center gap-2 bg-[#25D366] text-white font-body text-lg font-semibold px-8 py-4 rounded-lg hover:scale-[1.02] transition-transform duration-200"
            >
              <Phone size={20} />
              Book on WhatsApp
            </a>
          </div>
        </div>
      </div>
    </>
  );
}
