export default function Footer() {
  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const links = [
    { label: 'Home', href: '#home' },
    { label: 'Fleet', href: '#fleet' },
    { label: 'Features', href: '#features' },
    { label: 'Why Us', href: '#whyus' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <footer className="w-full bg-[#1A1A1A] border-t border-[rgba(245,245,240,0.15)] py-8 px-6 lg:px-12">
      <div className="max-w-[1280px] mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Copyright */}
          <p className="font-body text-sm text-[#A3A39B] order-3 md:order-1">
            &copy; 2024 Shri Sarvadnya Travels. All rights reserved.
          </p>

          {/* Quick Links */}
          <nav className="flex flex-wrap items-center justify-center gap-4 md:gap-6 order-1 md:order-2">
            {links.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="font-body text-sm text-[#A3A39B] hover:text-[#D4A843] transition-colors duration-200"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Tagline */}
          <p className="font-body text-sm text-[#A3A39B]/50 order-2 md:order-3">
            Designed for premium travel experiences
          </p>
        </div>
      </div>
    </footer>
  );
}
