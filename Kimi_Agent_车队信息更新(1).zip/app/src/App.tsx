import Navigation from './sections/Navigation';
import Hero from './sections/Hero';
import PhoneMarquee from './sections/PhoneMarquee';
import Fleet from './sections/Fleet';
import InteriorFeatures from './sections/InteriorFeatures';
import WhyChooseUs from './sections/WhyChooseUs';
import Contact from './sections/Contact';
import Footer from './sections/Footer';
import WhatsAppButton from './components/WhatsAppButton';

function App() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <main>
        <Hero />
        <PhoneMarquee />
        <Fleet />
        <InteriorFeatures />
        <WhyChooseUs />
        <Contact />
      </main>
      <Footer />
      <WhatsAppButton />
    </div>
  );
}

export default App;
