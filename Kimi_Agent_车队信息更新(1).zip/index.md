# Page: Home — Shri Sarvadnya Travels

Single-page website with six major sections, plus a global WhatsApp floating button and a fixed navigation bar. Dark/light alternating sections create visual rhythm. All text supports Hindi-English mixed content.

---

## Section: Navigation Bar

### Overview
Fixed top navigation bar providing persistent access to all sections and the primary WhatsApp booking CTA. Clean, minimal design that stays out of the way while always being accessible.

### Layout
- Full width, height `72px`, fixed top, `z-index: 50`
- Background: `rgba(26, 26, 26, 0.85)` with `backdrop-filter: blur(12px)`
- Content: flex row, `justify-content: space-between`, `align-items: center`
- Left: Business name "SHRI SARVADNYA TRAVELS" in `H3` font, weight 700, `Gold` color
- Center: Nav links — `HOME`, `FLEET`, `FEATURES`, `WHY US`, `CONTACT` in `Label` style, uppercase, `Text Primary (Dark BG)` color
- Right: "Book on WhatsApp" Primary Button (small variant, padding `0.75rem 1.25rem`)

### Elements

#### Element: "Business Name"
- Text: "SHRI SARVADNYA TRAVELS"
- Font: `H3` (Montserrat), weight 700
- Color: `Gold`
- Non-interactive (home link on click)

#### Element: "Nav Links"
- Items: `HOME`, `FLEET`, `FEATURES`, `WHY US`, `CONTACT`
- Font: `Label` style, uppercase
- Color: `Text Primary (Dark BG)`
- Hover: color transitions to `Gold`, `Duration Fast`
- Each links to corresponding section anchor

#### Element: "WhatsApp CTA Button"
- Text: "Book on WhatsApp"
- Style: Primary Button (small)
- Links to: `https://wa.me/919049168062`
- Hidden on mobile (<768px) — replaced by hamburger menu

### Mobile Behavior
- Below `768px`: Nav links hidden, hamburger icon (`Menu` from lucide) appears on right
- Hamburger tap: full-screen overlay slides in from right
- Overlay: `Dark` background, centered vertical nav link list, large `H3` font
- Close button (`X` icon) top-right of overlay
- Overlay links: same as desktop + "Book on WhatsApp" as prominent button
- Body scroll locked when overlay is open

### Animations
- Nav entrance: slides down from `translateY(-100%)` to `translateY(0)`, `Duration Medium`, on page load
- Nav link hover: color transition to `Gold`, `Duration Fast`

---

## Section: Hero

### Overview
Full-viewport dramatic hero section establishing the brand identity. Dark cinematic background with gold-accented vehicle silhouettes creates a premium first impression. The business name dominates as the focal point, with tagline in Hindi and English, and prominent CTA buttons driving immediate action.

### Layout
- Full viewport width and height (`100vh`)
- Background: `Dark (#0A0A0A)` base with subtle dark gradient overlay
- Vehicle silhouettes (white Force Traveller shapes) at very low opacity (`0.06`) positioned as decorative background elements, scattered across the section
- Content: centered vertically and horizontally using flexbox
- Text alignment: center
- Two CTA buttons side by side below the description
- Scroll indicator: small animated chevron at bottom center

### Elements

#### Element: "Hero Badge"
- Text: "PREMIUM TEMPO TRAVELLER & BUS RENTAL"
- Style: Badge/Label component
- Position: above the main title
- Margin-bottom: `1.5rem`

#### Element: "Hero Title"
- Text: "SHRI SARVADNYA TRAVELS"
- Font: `Display` (Montserrat, clamp 2.5-4.5rem), weight 800
- Color: `Text Primary (Dark BG)`
- Two lines max, centered
- Margin-bottom: `1rem`

#### Element: "Hero Subtitle (Hindi)"
- Text: "आपकी यात्रा, हमारी जिम्मेदारी"
- Font: `H2` (Montserrat/Noto Sans Devanagari), weight 600
- Color: `Gold`
- Margin-bottom: `1.5rem`

#### Element: "Hero Description"
- Text: "Luxury Tempo Traveller & Mini Bus on rent for all your travel needs. 17-seater to 50-seater vehicles available with AC, LED lights, music system & comfortable seating. 24-hour service available across Maharashtra."
- Font: `Body Large`, weight 400
- Color: `Text Secondary (Dark BG)`
- Max-width: `640px`, centered
- Margin-bottom: `2.5rem`

#### Element: "CTA Buttons Row"
- Flex row, centered, gap `1rem`
- Button 1: "📱 Book on WhatsApp" — Primary Button style
- Button 2: "📞 Call Now" — Secondary Button (Outline) style
- Below buttons: three phone numbers in a row, `Caption` font, `Text Secondary` color
- Numbers: "9049168062 | 7775009629 | 9028520865" with phone icon prefix

#### Element: "Scroll Indicator"
- Small animated chevron-down icon at bottom center
- Color: `Text Secondary (Dark BG)` at `0.5` opacity
- Gentle bounce animation: `translateY(0) -> translateY(8px) -> translateY(0)`, `2s` infinite

### Animations
- Hero badge: fade up, `Duration Slow`, delay `200ms`
- Hero title: fade up, `Duration Slow`, delay `400ms`
- Hero subtitle: fade up, `Duration Slow`, delay `600ms`
- Hero description: fade up, `Duration Slow`, delay `800ms`
- CTA buttons: fade up, `Duration Slow`, delay `1000ms`
- Phone numbers: fade up, `Duration Slow`, delay `1200ms`
- All use `Easing Dramatic`

### Responsive
- **Mobile (<768px):** Title scales down via clamp. CTA buttons stack vertically (full width). Phone numbers stack vertically below buttons.

---

## Section: Phone Marquee

### Overview
A full-width continuously scrolling marquee band displaying the three contact phone numbers in large, attention-grabbing typography. Creates a visual break between hero and fleet sections while reinforcing contact information.

### Layout
- Full viewport width, height `80px`
- Background: `Dark Surface`
- Border-top: `1px solid Border`
- Border-bottom: `1px solid Border`
- Content: single line of text, flex row, centered vertically
- Text overflows viewport and scrolls horizontally

### Elements

#### Element: "Marquee Content"
- Content (repeated for seamless loop):
  - "📞 9049168062" ◆ "📞 7775009629" ◆ "📞 9028520865" ◆ "WHATSAP BOOKING" ◆
- Font: `Marquee` (Montserrat, clamp 4-7rem), weight 900
- Color: `Gold` at `0.15` opacity (very subtle, decorative)
- Diamond separator (◆) in same style between numbers
- Animation: infinite horizontal scroll, `translateX(0) -> translateX(-50%)`, `40s` linear, seamless via duplicated content

### Animations
- Section entrance: fades in, `Duration Medium`
- Marquee starts scrolling immediately on page load

---

## Section: Our Fleet

### Overview
Showcases all three vehicles in the Shri Sarvadnya Travels fleet. This is the core content section — visitors come to see what vehicles are available. Three prominent vehicle cards display exterior and interior photos with key details. Dark background with gold accents maintains the premium aesthetic.

### Layout
- Full width, Background: `Dark (#0A0A0A)`
- Padding: `Section Padding` vertical, `Section Padding` horizontal
- Content max-width: `Content Max Width`, centered

#### Element: "Section Header"
- Badge: "OUR FLEET" — Badge component
- Title: "Premium Vehicles for Every Journey" — `H2` font, `Text Primary (Dark BG)`
- Subtitle: "17-seater Tempo Traveller to 32-seater Luxury Bus — choose the perfect vehicle for your group" — `Body Large`, `Text Secondary (Dark BG)`
- Margin-bottom: `3rem`

#### Element: "Vehicle Cards Grid"
- Grid: 3 columns on desktop, 1 column on mobile
- Gap: `Card Gap` (24px)

##### Card 1: "Night Queen — Force Traveller (MH 40 CT 1320)"
- Vehicle Card component
- Image: `1000047261.jpg` — front view of large Force Traveller with "श्री सर्वज्ञ" roof sign, MH40CT1320 plate, yellow FORCE grille
- Secondary image on hover: `1000047221.jpg` — side view at night with blue/amber LED lights glowing
- Badge overlay on image: "17 SEATER" — small badge, top-left of image
- Title: "Night Queen — Force Traveller" — `H3` font, weight 600
- Registration: "MH 40 CT 1320" — `Caption` font, `Gold` color
- Features list (flex wrap, gap `0.5rem`):
  - "AC" • "LED Disco Lights" • "Music System" • "Velvet Seats" • "Curtains" • "Roof Carrier"
- CTA: "Book This Vehicle" — Primary Button (small), links to WhatsApp

##### Card 2: "Shri Sarvadnya — Force Traveller (MH 09 CV 0972)"
- Vehicle Card component
- Image: `1000047243.jpg` — front-left view of compact Force Traveller at sunset, "श्री सर्वज्ञ" on roof
- Secondary image on hover: `1000047253.jpg` — interior view showing velvet seats and LED ceiling lights
- Badge overlay: "14 SEATER"
- Title: "Shri Sarvadnya Traveller"
- Registration: "MH 09 CV 0972"
- Features: "AC" • "LED Lights" • "Music System" • "Comfortable Seats" • "Curtains"
- CTA: "Book This Vehicle" — Primary Button (small)

##### Card 3: "Luxury Mini Bus — Brand New Recliner"
- Vehicle Card component
- Image: `1000047260.jpg` — interior view of brand new white recliner seats with plastic wrap, blue ambient LED lighting, large TV screen at front
- Secondary image on hover: `1000047229.jpg` — alternate angle of same luxury interior
- Badge overlay: "32 SEATER"
- Title: "Luxury Mini Bus — Recliner Seats"
- Registration: "Brand New Vehicle"
- Features: "AC" • "Recliner Seats" • "LED TV" • "Ambient Lighting" • "Seat Pockets" • "Premium Interior"
- CTA: "Book This Vehicle" — Primary Button (small)

### Animations
- Section header: fade up on scroll, `Duration Slow`, `Easing Smooth`
- Vehicle cards: staggered fade up, `Stagger Default` between cards
- Card hover: scale `1.03`, shadow elevation, `Duration Medium`

### Responsive
- **Tablet (<1024px):** 2-column grid (first row: 2 cards, second row: 1 card centered)
- **Mobile (<768px):** Single column stack, cards full width

---

## Section: Interior Features

### Overview
A visual showcase of the luxury interior amenities across the fleet. This section uses a dramatic dark background with a grid of feature cards, each highlighting a specific amenity with an icon and description. The focus is on the premium experience inside the vehicles — LED lighting, comfort, entertainment.

### Layout
- Full width, Background: `Dark (#0A0A0A)`
- Top border: `1px solid Border`
- Padding: `Section Padding` vertical, `Section Padding` horizontal
- Content max-width: `Content Max Width`, centered

#### Element: "Section Header"
- Badge: "INTERIOR FEATURES" — Badge component
- Title: "Travel in Comfort & Style" — `H2` font
- Subtitle: "Every vehicle is equipped with premium amenities to make your journey memorable" — `Body Large`, `Text Secondary`
- Margin-bottom: `3rem`

#### Element: "Features Grid"
- Grid: 4 columns on desktop, 2 columns on tablet, 1 column on mobile
- Gap: `Card Gap`
- 8 feature cards total

##### Feature Card Template
- Feature Card component (dark variant)
- Background: `Dark Surface`, Border-radius: `12px`, Padding: `2rem`
- Top: Icon (from Lucide icons, `3rem`, `Gold` color)
- Title: `H3` font, weight 600, `Text Primary (Dark BG)`, margin-top `1rem`
- Description: `Body` font, `Text Secondary (Dark BG)`, margin-top `0.5rem`

##### Card 1: "Green LED Ceiling Lights"
- Icon: Custom SVG — circular LED ring pattern (green rings with small dots)
- Title: "Green LED Ceiling Lights"
- Description: "Beautiful multi-color LED rings on ceiling with disco/party lighting mode for a festive atmosphere"

##### Card 2: "Fully Air Conditioned"
- Icon: `Wind` from lucide-react
- Title: "Fully Air Conditioned"
- Description: "Powerful AC with roof-mounted units ensuring comfortable temperature even in peak summer"

##### Card 3: "Music System"
- Icon: `Music` from lucide-react
- Title: "Music System"
- Description: "High-quality sound system with speakers throughout the vehicle for an enjoyable journey"

##### Card 4: "LED TV Screen"
- Icon: `Tv` from lucide-react
- Title: "LED TV Screen"
- Description: "Large screen LED TV for entertainment — perfect for long journeys with movies and music videos"

##### Card 5: "Luxury Velvet Seats"
- Icon: `Users` from lucide-react
- Title: "Luxury Velvet Seats"
- Description: "Premium cream/beige velvet seat covers with comfortable cushioning for fatigue-free travel"

##### Card 6: "Recliner Seats (New Bus)"
- Icon: `Star` from lucide-react
- Title: "Recliner Seats (New Bus)"
- Description: "Brand new white recliner seats with individual pockets and premium comfort in our luxury mini bus"

##### Card 7: "Privacy Curtains"
- Icon: Custom SVG — curtain shape
- Title: "Privacy Curtains"
- Description: "Dark curtains on all windows for privacy and shade, creating a personal space for your group"

##### Card 8: "Roof Luggage Carrier"
- Icon: `MapPin` from lucide-react
- Title: "Roof Luggage Carrier"
- Description: "Spacious roof carrier for extra luggage — no need to compromise on baggage for group travel"

### Animations
- Section header: fade up on scroll
- Feature cards: staggered fade up, 8 cards with `Stagger Default` timing
- Card hover: `translateY(-8px)` lift, shadow deepens, `Duration Fast`

### Responsive
- **Tablet (<1024px):** 2-column grid
- **Mobile (<768px):** Single column, cards full width

---

## Section: Why Choose Us

### Overview
A trust-building section presented on a clean white background for visual contrast. Uses a 4-column grid of feature cards with icons, each highlighting a key reason to choose Shri Sarvadnya Travels. This section breaks the dark-theme pattern to create visual relief and emphasize credibility.

### Layout
- Full width, Background: `White (#FFFFFF)`
- Padding: `Section Padding` vertical, `Section Padding` horizontal
- Content max-width: `Content Max Width`, centered

#### Element: "Section Header"
- Badge: "WHY CHOOSE US" — Badge component (adapted for light bg: bg `rgba(212,168,67,0.1)`, text `Gold`)
- Title: "Why Choose Shri Sarvadnya Travels?" — `H2` font, `Text Primary (Light BG)`
- Subtitle: "We go the extra mile to ensure your journey is safe, comfortable, and memorable" — `Body Large`, `Text Secondary (Light BG)`
- Margin-bottom: `3rem`

#### Element: "Why Us Cards Grid"
- Grid: 4 columns on desktop, 2 columns on tablet, 1 column on mobile
- Gap: `Card Gap`

##### Card 1: "24/7 Service Available"
- Feature Card (light variant)
- Icon: `Clock` from lucide-react, `3rem`, `Gold` color
- Title: "24/7 Service Available"
- Description: "Round-the-clock service available. Book anytime — we're always ready for your journey."

##### Card 2: "Experienced Drivers"
- Icon: `Shield` from lucide-react
- Title: "Experienced Drivers"
- Description: "Professional, licensed, and courteous drivers with years of experience on Maharashtra roads."

##### Card 3: "Well-Maintained Fleet"
- Icon: `Star` from lucide-react
- Title: "Well-Maintained Fleet"
- Description: "All vehicles regularly serviced and inspected. Clean, hygienic interiors for every trip."

##### Card 4: "Affordable Pricing"
- Icon: Custom SVG — rupee/price tag icon
- Title: "Affordable Pricing"
- Description: "Competitive rates with no hidden charges. Get the best value for premium comfort."

##### Card 5: "All India Permit"
- Icon: `MapPin` from lucide-react
- Title: "All India Permit"
- Description: "Our vehicles have all-India permits. Travel anywhere in India without any restrictions."

##### Card 6: "Multiple Vehicle Options"
- Icon: `Users` from lucide-react
- Title: "Multiple Vehicle Options"
- Description: "From 14-seater to 32-seater — choose the right vehicle size for your group and budget."

##### Card 7: "Easy WhatsApp Booking"
- Icon: Custom SVG — WhatsApp icon
- Title: "Easy WhatsApp Booking"
- Description: "Book instantly via WhatsApp. Share your travel plan and get a quick confirmation."

##### Card 8: "Punctual Service"
- Icon: `Clock` from lucide-react
- Title: "Punctual Service"
- Description: "We value your time. Our vehicles arrive on time, every time — guaranteed."

### Animations
- Section header: fade up on scroll
- Cards: staggered fade up, `Stagger Default` between cards
- Card hover: `translateY(-8px)` lift, subtle shadow

### Responsive
- **Tablet (<1024px):** 2-column grid
- **Mobile (<768px):** Single column

---

## Section: Contact

### Overview
The final content section providing all contact information in a clear, easy-to-use layout. Dark background returns for a strong closing impression. Two-column layout: left side with business name and tagline, right side with phone numbers, WhatsApp CTA, and service area information.

### Layout
- Full width, Background: `Dark (#0A0A0A)`
- Top border: `1px solid Border`
- Padding: `Section Padding` vertical, `Section Padding` horizontal
- Content max-width: `Content Max Width`, centered
- Two-column layout: 50/50 on desktop, stacked on mobile

### Elements

#### Left Column: "Business Info"

##### Element: "Contact Title"
- Text: "Contact Us"
- Font: `H2`, weight 700, `Text Primary (Dark BG)`
- Margin-bottom: `1rem`

##### Element: "Business Name"
- Text: "Shri Sarvadnya Travels"
- Font: `H3`, weight 600, `Gold`
- Margin-bottom: `0.5rem`

##### Element: "Tagline"
- Text: "आपकी यात्रा, हमारी जिम्मेदारी"
- Font: `Body Large`, weight 500, `Text Secondary`
- Margin-bottom: `1.5rem`

##### Element: "Service Description"
- Text: "Tempo Traveller & Mini Bus on Rent — 17 Seater, 20 Seater, 32 Seater, 50 Seater, AC, Video Coach available. Serving Bhandara and all of Maharashtra."
- Font: `Body`, `Text Secondary`
- Max-width: `480px`

#### Right Column: "Contact Details"

##### Element: "Phone Numbers Card"
- Background: `Dark Surface`, Border-radius: `12px`, Padding: `2rem`
- Border: `1px solid Border`

**Primary Number:**
- Icon: Phone icon, `Gold`
- Label: "Primary (WhatsApp)" — `Caption`, uppercase, `Text Secondary`
- Number: "9049168062" — `H3` font, weight 700, `Text Primary (Dark BG)`
- WhatsApp badge: "WhatsApp" — small green badge

**Secondary Numbers:**
- Number 2: "7775009629" — `Body Large`, weight 600
- Number 3: "9028520865" — `Body Large`, weight 600
- All numbers displayed in a vertical list with `1rem` gap

##### Element: "WhatsApp CTA"
- Large prominent button below phone card
- Full width of right column
- Text: "📱 Book on WhatsApp Now"
- Style: WhatsApp Green background, white text, large padding `1.25rem 2rem`
- Border-radius: `8px`
- Links to: `https://wa.me/919049168062`
- Hover: scale `1.02`, intensified shadow

##### Element: "Service Area"
- Below WhatsApp CTA
- Icon: `MapPin`, `Gold`
- Text: "Lakshmi Nagar, Vaishali Nagar Road, Khat Road, Bhandara 441904"
- Font: `Body`, `Text Secondary`
- Margin-top: `1.5rem`

##### Element: "Services Tags"
- Flex wrap row of small tags below service area
- Tags: "भारत दर्शन" • "महाराष्ट्र दर्शन" • "चार-धाम यात्रा" • "गोवा पिकनिक" • "विवाह समारंभ" • "कार्पोरेट मीटिंग"
- Each tag: `Caption` font, `Dark Surface` background, `1px solid Border` border, Border-radius `20px`, Padding `0.375rem 0.875rem`
- Color: `Text Secondary`

### Animations
- Left column: fade up on scroll, `Duration Slow`
- Right column: fade up on scroll, `Duration Slow`, delay `200ms`
- Phone card: subtle scale from `0.98` to `1.0`

### Responsive
- **Mobile (<768px):** Columns stack vertically. Left column first (title + description), right column second (phone card + WhatsApp CTA)

---

## Section: Footer

### Overview
Minimal footer with business name, quick links, and copyright. Clean and unobtrusive.

### Layout
- Full width, Background: `Dark Surface`
- Border-top: `1px solid Border`
- Padding: `2rem` vertical, `Section Padding` horizontal
- Content max-width: `Content Max Width`, centered
- Flex row: space-between on desktop, stacked on mobile

### Elements

#### Element: "Footer Left"
- Text: "© 2024 Shri Sarvadnya Travels. All rights reserved."
- Font: `Caption`, `Text Secondary`

#### Element: "Footer Center"
- Quick links: `Home`, `Fleet`, `Features`, `Why Us`, `Contact`
- Font: `Caption`, `Text Secondary`
- Hover: `Gold` color
- Links scroll to respective sections

#### Element: "Footer Right"
- Text: "Designed for premium travel experiences"
- Font: `Caption`, `Text Secondary` at `0.5` opacity

### Responsive
- **Mobile (<768px):** Centered stack, all elements centered vertically
